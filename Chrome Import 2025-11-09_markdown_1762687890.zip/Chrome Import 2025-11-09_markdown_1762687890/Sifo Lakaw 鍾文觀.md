- Pipalofasaran to Sowal no Pangcah/'Amis 
  台灣阿美族語言永續發展學會/原民會阿美族語言推動組織  
  Pangcah Indigenous Language Regeneration Association  
-
