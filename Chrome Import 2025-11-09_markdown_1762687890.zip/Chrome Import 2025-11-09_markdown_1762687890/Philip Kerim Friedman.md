- [[My]] Work Address (Chinese)
	- 傅可恩教授 
	  國立東華大學族群關係與文化學系   
	  花蓮縣壽豐鄉志學村大學路二段一號   
	  974003  
- [[My]] Work Address (English)
	- Dr. P. Kerim Friedman 
	  NDHU, Dept. of Ethnic Relations & Cultures   
	  No. 1, Sec. 2, Da Hsueh Rd.,   
	  Shoufeng, Hualien 974003   
	  TAIWAN  
- [[My]] Home address (Chinese)
	- 10851臺北市萬華區廣州街81巷5號3樓
- [[My]] Home address (English)
	- 3F, No. 5, Lane 81, Guangzhou Street, Wanhua District, Taipei City, 108
- [[My]] Domicile
	- 47 Pond Park Rd
	  Woodstoc, NY 12498  
-
