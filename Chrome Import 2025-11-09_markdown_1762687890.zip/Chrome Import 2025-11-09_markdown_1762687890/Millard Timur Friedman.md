- Home Address
	- M. FRIEDMAN et Mme. TOLENTINO
	  19 rue Lucien Sampaix  
	  code B0A69, esc. RUE, BAL 7  
	  75010 Paris, France
