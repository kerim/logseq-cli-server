- MA Translator ZH ENG GER 
  中英德 翻譯學家， 語言學 及 文化學碩士  
  D-10317 Berlin  
  Germany  
- First email (2020)
	- I am an MA Translation studies alumni from the University of Mainz, Germany, Dept. of Translation, Language and Culture Studies, starting my research with case study target in Taiwan to specify my goals during this visit. Following a seminar on 'Language Education Policies in Asia' by Prof. Dr. Henning Klöter at Humboldt University Berlin, presenting a paper on the Status Quo of Indigenous Languages, I have decided to continue with in-depth study on Language Education in Taiwan.
	- My focus in Multi-Lingualism in Taiwan is set on 母語課,國語 and 對外英語 with regard to the Language Development Act. I have so far been able to watch several classes for Bunun and Amis Languages and English at the elementary level in Taipei by Skype sessions with little sound quality.
